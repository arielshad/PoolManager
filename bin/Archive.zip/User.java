import java.util.ArrayList;
import java.util.concurrent.Callable;

public class User {

	
	/**
	 * Solution.
	 *
	 * @param k the number of 1.1 expressions
	 * @param r the number of 1.2 expressions
	 * @param n_vals the n_vals array of k values for the for expression  1.1 
	 * @param l_vals the l_vals array of r values for the multiplay part of 1.2
	 * @param m_vals the m_vals array of r values for the summary part of 1.2
	 * @param t the t size of the tasks-queue of the PoolManeger
	 * @param s the s maximum number of summands that pool-thread can handle
	 * @param m the m maximum number of multiplicands the pool-thread can handle
	 * @param p the the number of PoolThreads that the PoolMangers creates
	 */
	public static void solution(int k, int r, ArrayList<Integer> n_vals,  ArrayList<Integer> l_vals, ArrayList<Integer> m_vals, int t, int s, int m, int p){
		
	}
	
	public static void main(String[] args) {
		//set pool maneger		
		PoolManeger poolManeger = PoolManeger.getInstace();
		poolManeger.setMaxSizeOfTaskQueue(4);
		poolManeger.setNumOfThread(2);
		poolManeger.run();
		
		//add task to pool
		Ex1 task = new Ex1();
		
		poolManeger.addTask(task);
		
	}

}

class Ex1 implements Callable<Result>{

	@Override
	public Result call() throws Exception {
		System.out.println("haha");
		Thread.sleep(1000);
		return null;
	}
	
}



