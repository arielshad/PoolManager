import java.util.concurrent.Callable;

//the singelton design pattern to prevent of creating more then 1 pool maneger
public class PoolManeger extends Thread{

	private static PoolManeger instance  = new PoolManeger();
	
	private int numOfThread = 10;
	private int maxSizeOfTaskQueue = Integer.MAX_VALUE;
	private Object lock = new Object();
	
	private BlockingQueue<PoolThread> threads_queue; //available threads
	private BlockingQueue<PoolThread> running_threads_queue; // not available threads
	private BlockingQueue<Callable<Result>> task_queue; // waiting tasks
	
	
	private PoolManeger() {
		// TODO Auto-generated constructor stub
	}
	
	public static PoolManeger getInstace(){
		return instance;
	}
	
	//add task to queue
	public void addTask(Callable<Result> task){
		try {
			task_queue.add(task);
			System.out.println("haha123");
			lock.notifyAll();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	private void init(){
		threads_queue = new BlockingQueue<PoolThread>(numOfThread);
		running_threads_queue = new BlockingQueue<PoolThread>(numOfThread);
		task_queue = new BlockingQueue<Callable<Result>>(maxSizeOfTaskQueue);
		
		//create threads
		for (int i = 0; i < numOfThread; i++) {
			PoolThread pt = new PoolThread();
			pt.start();
			
			try {
				threads_queue.add(pt);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	@Override
	public void run() {
		//Initialize queues
		this.init();
		
		//start working.
		synchronized (lock) {
			while (true) {
				//wait for task
				
				while (task_queue.size()==0) {
					System.out.println("haha");
					try {
						lock.wait();						
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("haha");
				}
				
				
				//now we have task - pop thread and push task
				try {
					//pop thread
					PoolThread thread = (PoolThread) threads_queue.remove();

					//insert thread to running queue
					running_threads_queue.add(thread);
					
					//pop task					
					Callable<Result> task = (Callable<Result>) task_queue.remove();
					
					//push task to thread
					thread.addTask(task);
					

				} catch (InterruptedException e) {
					e.printStackTrace();
				} 
				
				
			}	
		}
		
		
		
		
		
	}


	public void setMaxSizeOfTaskQueue(int maxSizeOfQueue) {
		this.maxSizeOfTaskQueue = maxSizeOfQueue;
	}


	public void setNumOfThread(int numOfThread) {
		this.numOfThread = numOfThread;
	}

}
