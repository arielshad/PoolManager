public enum ExpressionType {
	MUL, SUM 
}