import java.util.concurrent.Callable;


public abstract class Task implements Callable<Double>{

}
