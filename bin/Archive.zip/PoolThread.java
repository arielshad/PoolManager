import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;


public class PoolThread extends Thread{
		
	private Object lock = new Object();
	private BlockingQueue<Callable<Result>> taskQueue;
	
	public PoolThread() {
		taskQueue = new BlockingQueue<>(1);
	}
	
	@SuppressWarnings("rawtypes")
	public void addTask(Callable task){
		try {
			taskQueue.add(task);
			lock.notifyAll();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		while(true){
			synchronized (lock) {
				while (taskQueue.size()==0) {
					try {
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				try {
					//now we have a task, lets inesrt it into futureTask and w8 for result
					FutureTask<Result> futureTask = new FutureTask<Result>((Callable<Result>) taskQueue.remove());
					futureTask.run();
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}			
		}		
	}
}
