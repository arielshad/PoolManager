
public class Result {

}
