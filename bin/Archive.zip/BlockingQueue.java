import java.util.LinkedList;
import java.util.List;

public class BlockingQueue<T>{

	
	private List<T> queue = new LinkedList<T>();
	private int limit;
	private Object lock = new Object();

	public BlockingQueue(int limit){
		this.limit = limit;
	}


	public int size(){
		return this.queue.size();
	}
	
	@SuppressWarnings("unchecked")
	public void add(Object item) throws InterruptedException  {
		synchronized (lock) {
			while(this.queue.size() == this.limit) {
				lock.wait();
			}
			if(this.queue.size() == 0) {
				lock.notifyAll();
			}
			this.queue.add((T) item);
		}


	}


	public Object remove() throws InterruptedException{
		synchronized (lock) {
			while(this.queue.size() == 0){
				lock.wait();
			}
			if(this.queue.size() == this.limit){
				lock.notifyAll();
			}
			
			return this.queue.remove(0);	
		}    
	}

}