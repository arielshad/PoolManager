//task interfrace for executing tasks.
public interface ITask{
	void execute(Object o);
}
